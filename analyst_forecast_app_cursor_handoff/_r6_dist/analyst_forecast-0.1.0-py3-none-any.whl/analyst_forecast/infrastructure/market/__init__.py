"""市場データprovider。"""
