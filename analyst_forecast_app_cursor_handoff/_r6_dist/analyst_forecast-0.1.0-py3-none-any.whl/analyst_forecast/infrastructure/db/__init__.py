"""SQLite永続化。"""
